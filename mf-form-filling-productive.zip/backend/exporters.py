from __future__ import annotations
import json
from typing import Dict, Any
import pandas as pd

def to_json_bytes(obj: Dict[str, Any]) -> bytes:
    return json.dumps(obj, indent=2, ensure_ascii=False).encode("utf-8")

def to_csv_bytes(bank_outputs: Dict[str, Any]) -> bytes:
    rows = []
    for bank, payload in bank_outputs.items():
        fields = payload.get("fields", {})
        for field, info in fields.items():
            rows.append({
                "bank": bank,
                "field": field,
                "value": info.get("value"),
                "confidence": info.get("confidence"),
                "evidence": info.get("evidence")
            })
    df = pd.DataFrame(rows)
    return df.to_csv(index=False).encode("utf-8")
