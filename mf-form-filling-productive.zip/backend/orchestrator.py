from __future__ import annotations
from typing import Dict, Any, List
from .registry import CORE_SCHEMA, BANK_REGISTRY
from .llm import extract_fields_with_genai
from .validator import validate

def _flatten_core_fields() -> List[str]:
    out = []
    for _, fields in CORE_SCHEMA.items():
        out.extend(fields)
    return out

def required_fields_for_bank(bank_name: str) -> List[str]:
    core = _flatten_core_fields()
    extra = BANK_REGISTRY[bank_name].get("required_fields", [])
    # preserve order, unique
    seen = set()
    all_fields = []
    for f in core + extra:
        if f not in seen:
            seen.add(f)
            all_fields.append(f)
    return all_fields

def process_bank(bank_name: str, pdf_text: str, confidence_threshold: float = 0.6) -> Dict[str, Any]:
    fields = required_fields_for_bank(bank_name)
    extracted = extract_fields_with_genai(pdf_text=pdf_text, field_list=fields, bank_name=bank_name)
    missing, normalized = validate(extracted, required=fields, confidence_threshold=confidence_threshold)
    confidence = 0.0
    if normalized:
        confidence = sum(v.get("confidence", 0.0) for v in normalized.values()) / max(1, len(normalized))
    return {
        "bank": bank_name,
        "missing_fields": missing,
        "confidence": round(confidence, 2),
        "fields": normalized
    }
