from __future__ import annotations
from typing import List, Tuple
from pypdf import PdfReader

def extract_text_from_pdf_file(file_obj) -> str:
    reader = PdfReader(file_obj)
    chunks = []
    for i, page in enumerate(reader.pages):
        try:
            t = page.extract_text() or ""
        except Exception:
            t = ""
        if t.strip():
            chunks.append(f"\n\n--- Page {i+1} ---\n{t}")
    return "".join(chunks).strip()

def extract_text_from_many(uploaded_files) -> Tuple[str, List[str]]:
    texts = []
    names = []
    for f in uploaded_files or []:
        names.append(getattr(f, "name", "uploaded.pdf"))
        try:
            # pypdf can read file-like; Streamlit UploadedFile supports this.
            texts.append(f"\n\n### FILE: {names[-1]}\n" + extract_text_from_pdf_file(f))
        except Exception:
            texts.append(f"\n\n### FILE: {names[-1]}\n" + "")
    return ("".join(texts).strip(), names)
