# Bank registry + baseline schema used across banks.
# Bank-specific required fields are added on top of the baseline schema.

CORE_SCHEMA = {
    "Personal Details": [
        "Full Name", "Nationality", "DOB", "Passport No", "Emirates ID", "Marital Status",
        "UAE Address", "UAE Mobile Number", "Email Address", "Gender"
    ],
    "Employment": [
        "Employer Name", "Designation", "Employment Start Date", "Declared Monthly Salary"
    ],
    "Financials": [
        "Bank Name (Salary Acct)", "IBAN (Salary Acct)", "Detected Monthly Credit",
        "Other Income", "Existing Loans/EMI", "Credit Card Limits"
    ],
    "Property & Loan": [
        "Property Type", "Property Value", "Loan Amount Requested", "Tenure (Years)",
        "Down Payment", "Developer/Project Name"
    ],
    "Co-Applicant": [
        "Co-applicant Full Name", "Co-applicant Nationality", "Co-applicant Employer",
        "Co-applicant Monthly Salary"
    ]
}

# These required fields come from your earlier Jupyter prototype (backend (2).py).
# They are *additional* bank-specific fields on top of CORE_SCHEMA.
BANK_REGISTRY = {
    "First Abu Dhabi Bank (FAB)": {
        "required_fields": [
            "Company Address", "HR Contact Name", "HR Contact Number"
        ],
        "template_file": "FAB_Mortgage_App.pdf"
    },
    "Dubai Islamic Bank (DIB)": {
        "required_fields": [
            "Employer PO Box", "Office Telephone Number"
        ],
        "template_file": "DIB_Mortgage_App.pdf"
    },
    "Abu Dhabi Islamic Bank (ADIB)": {
        "required_fields": [
            "Preferred Branch", "Home Country Address"
        ],
        "template_file": "ADIB_Mortgage_App.pdf"
    },
    "Abu Dhabi Commercial Bank (ADCB)": {
        "required_fields": [
            "Residence Type (Own/Rent/Company)", "Years in UAE"
        ],
        "template_file": "ADCB_Mortgage_App.pdf"
    },
    "Mashreq Bank": {
        "required_fields": [
            "Reference 1 Full Name", "Reference 1 Contact No",
        ],
        "template_file": "Mashreq_Mortgage_App.pdf"
    },
    "RAKBANK": {
        "required_fields": [
            "Salary Transfer? (Yes/No)"
        ],
        "template_file": "RAK_Mortgage_App.pdf"
    },
    "Commercial Bank of Dubai (CBD)": {
        "required_fields": [
            "Mother's Name (Identification Feature)", "Permanent Home Country Address",
        ],
        "template_file": "CBD_Mortgage_App.pdf"
    },
    "Emirates NBD (ENBD)": {
        "required_fields": [
            "Reference 1 Full Name", "Reference 1 Contact No",
            "Reference 2 Full Name", "Reference 2 Contact No"
        ],
        "template_file": "ENBD_Mortgage_App.pdf"
    }
}
