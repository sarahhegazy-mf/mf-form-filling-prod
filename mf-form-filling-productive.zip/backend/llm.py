from __future__ import annotations
import json
from typing import Dict, Any, List
import streamlit as st
from google import genai

def _client() -> genai.Client:
    # Uses Streamlit secrets; caller must have .streamlit/secrets.toml
    key = st.secrets.get("GEMINI_API_KEY", "")
    if not key:
        raise RuntimeError("GEMINI_API_KEY missing. Add it to .streamlit/secrets.toml")
    return genai.Client(api_key=key)

def extract_fields_with_genai(
    pdf_text: str,
    field_list: List[str],
    bank_name: str,
    max_output_tokens: int = 2048,
) -> Dict[str, Any]:
    """Return dict of {field: {value, confidence, evidence}}."""
    client = _client()

    # Deterministic
    prompt = f"""You are a mortgage operations assistant.
Extract the requested fields for bank: {bank_name} from the uploaded client documents.
Return ONLY valid JSON (no markdown, no commentary).

For each field, return:
- value: string|number|null
- confidence: number between 0 and 1
- evidence: short text snippet from the documents (or null)

Rules:
- If missing, use null and confidence 0
- Do not invent values.
- Keep numbers numeric (no commas).
- Output must be a JSON object where keys are exactly the field names.

FIELDS:
{json.dumps(field_list, indent=2)}

DOCUMENTS:
{pdf_text}
"""

    resp = client.models.generate_content(
        model="gemini-1.5-pro",
        contents=prompt,
        config={
            "temperature": 0,
            "max_output_tokens": max_output_tokens,
            "response_mime_type": "application/json",
        }
    )

    try:
        data = json.loads(resp.text)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        raise RuntimeError(f"LLM returned non-JSON output: {e}\nRaw: {resp.text[:500]}")
