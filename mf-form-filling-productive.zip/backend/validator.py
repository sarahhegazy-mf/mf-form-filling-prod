from __future__ import annotations
from typing import Dict, Any, List, Tuple

def normalize_value(v):
    if v is None:
        return None
    if isinstance(v, str):
        s = v.strip()
        return s if s else None
    return v

def validate(fields: Dict[str, Any], required: List[str], confidence_threshold: float = 0.6) -> Tuple[List[str], Dict[str, Any]]:
    """Returns (missing_fields, normalized_fields)."""
    normalized = {}
    missing = []
    for k, obj in fields.items():
        if isinstance(obj, dict):
            value = normalize_value(obj.get("value"))
            conf = obj.get("confidence", 0) or 0
            normalized[k] = {
                "value": value,
                "confidence": float(conf) if isinstance(conf, (int, float)) else 0.0,
                "evidence": obj.get("evidence")
            }
        else:
            normalized[k] = {"value": normalize_value(obj), "confidence": 0.0, "evidence": None}

    for f in required:
        v = normalized.get(f, {}).get("value")
        conf = normalized.get(f, {}).get("confidence", 0.0)
        if v is None or conf < confidence_threshold:
            missing.append(f)

    return missing, normalized
