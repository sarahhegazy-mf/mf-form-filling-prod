import sys
from pathlib import Path

# Ensure project root is on PYTHONPATH (Streamlit deploy-safe)
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import streamlit as st
from backend.registry import BANK_REGISTRY
from backend.pdf_text import extract_text_from_many
from backend.orchestrator import process_bank
from backend.exporters import to_json_bytes, to_csv_bytes

st.set_page_config(page_title="Mortgage Form Filling Copilot", layout="wide")
st.title("🏦 Mortgage Form Filling Copilot")

# --- session state ---
st.session_state.setdefault("selected_banks", [])
st.session_state.setdefault("doc_names", [])
st.session_state.setdefault("pdf_text", "")
st.session_state.setdefault("outputs", {})           # bank -> payload
st.session_state.setdefault("chat_history", [])      # list of dicts
st.session_state.setdefault("active_missing", [])    # queue
st.session_state.setdefault("active_bank", None)     # which bank we're collecting for

with st.sidebar:
    st.header("1) Select banks")
    banks = st.multiselect("Target banks (max 3)", list(BANK_REGISTRY.keys()), max_selections=3)
    st.session_state.selected_banks = banks

    st.header("2) Upload client docs")
    uploads = st.file_uploader(
        "Upload PDFs (EID, passport, salary cert, bank statements, etc.)",
        type=["pdf"],
        accept_multiple_files=True
    )

    extract_clicked = st.button("🔍 Extract & Validate", use_container_width=True)

# --- Extract pipeline ---
if extract_clicked:
    if not st.session_state.selected_banks:
        st.error("Select at least 1 bank.")
        st.stop()
    if not uploads:
        st.error("Upload at least 1 PDF.")
        st.stop()

    with st.spinner("Reading PDFs..."):
        pdf_text, names = extract_text_from_many(uploads)
        st.session_state.pdf_text = pdf_text
        st.session_state.doc_names = names

    outputs = {}
    with st.spinner("Extracting fields with Gemini..."):
        for bank in st.session_state.selected_banks:
            outputs[bank] = process_bank(bank, pdf_text=st.session_state.pdf_text, confidence_threshold=0.6)

    st.session_state.outputs = outputs

    # pick first bank with missing fields to start chat
    for bank in st.session_state.selected_banks:
        missing = outputs[bank]["missing_fields"]
        if missing:
            st.session_state.active_bank = bank
            st.session_state.active_missing = missing.copy()
            st.session_state.chat_history = [{
                "role": "assistant",
                "content": f"I found missing/low-confidence fields for **{bank}**. Let's fill them. First: **{missing[0]}**"
            }]
            break
    else:
        st.session_state.active_bank = None
        st.session_state.active_missing = []
        st.session_state.chat_history = [{
            "role": "assistant",
            "content": "✅ All required fields were extracted with sufficient confidence for the selected bank(s)."
        }]

col1, col2 = st.columns([1.1, 0.9], gap="large")

with col1:
    st.subheader("Uploaded documents preview")
    if st.session_state.doc_names:
        st.write(", ".join(st.session_state.doc_names))
    with st.expander("Show extracted text (first 3,000 chars)"):
        st.code((st.session_state.pdf_text or "")[:3000])

with col2:
    st.subheader("Bank outputs")
    if st.session_state.outputs:
        for bank, payload in st.session_state.outputs.items():
            st.markdown(f"**{bank}** — avg confidence: `{payload['confidence']}`")
            if payload["missing_fields"]:
                st.warning(f"Missing/low-confidence ({len(payload['missing_fields'])}): " + ", ".join(payload["missing_fields"][:6]) + ("..." if len(payload["missing_fields"])>6 else ""))
            else:
                st.success("No missing fields flagged.")
    else:
        st.info("Run **Extract & Validate** to generate outputs.")

st.divider()
st.subheader("💬 Advisor Chat to fill missing fields")

# Render chat history
for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Chat input (only if we have missing queue)
if st.session_state.active_bank and st.session_state.active_missing:
    user_msg = st.chat_input("Type the value for the requested field…")
    if user_msg:
        # record user
        st.session_state.chat_history.append({"role": "user", "content": user_msg})

        bank = st.session_state.active_bank
        field = st.session_state.active_missing.pop(0)

        # set manual value with high confidence
        st.session_state.outputs[bank]["fields"][field] = {
            "value": user_msg.strip(),
            "confidence": 0.99,
            "evidence": "manual_input"
        }

        # Recompute missing list for that bank (simple: remove if filled)
        st.session_state.outputs[bank]["missing_fields"] = [
            f for f in st.session_state.outputs[bank]["missing_fields"] if f != field
        ]

        if st.session_state.active_missing:
            nxt = st.session_state.active_missing[0]
            st.session_state.chat_history.append({"role": "assistant", "content": f"Got it ✅ Next: **{nxt}**"})
        else:
            st.session_state.chat_history.append({"role": "assistant", "content": f"Done ✅ No more missing fields for **{bank}**."})

            # move to next bank with missing fields
            next_bank = None
            for b in st.session_state.selected_banks:
                if st.session_state.outputs.get(b, {}).get("missing_fields"):
                    next_bank = b
                    break
            if next_bank:
                st.session_state.active_bank = next_bank
                st.session_state.active_missing = st.session_state.outputs[next_bank]["missing_fields"].copy()
                st.session_state.chat_history.append({"role": "assistant", "content": f"Now let's fill **{next_bank}**. First: **{st.session_state.active_missing[0]}**"})
            else:
                st.session_state.active_bank = None
                st.session_state.active_missing = []
                st.session_state.chat_history.append({"role": "assistant", "content": "✅ All selected banks are complete."})

        st.rerun()
else:
    st.info("After extraction, missing fields (if any) will appear here and I’ll ask you for them one by one.")

st.divider()
st.subheader("⬇️ Export")

if st.session_state.outputs:
    json_bytes = to_json_bytes(st.session_state.outputs)
    csv_bytes = to_csv_bytes(st.session_state.outputs)

    st.download_button("Download JSON", data=json_bytes, file_name="mortgage_outputs.json", mime="application/json")
    st.download_button("Download CSV", data=csv_bytes, file_name="mortgage_outputs.csv", mime="text/csv")
else:
    st.caption("Run extraction first to enable export.")
