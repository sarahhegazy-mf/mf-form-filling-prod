# Mortgage Form Filling Copilot (Production Starter)

This repo contains a Streamlit app that:
- Lets an advisor select 1–3 banks
- Upload a client document pack (PDFs)
- Extracts structured fields using Gemini (google.genai)
- Flags missing required fields and collects them via an in-app chat
- Exports bank-specific JSON/CSV outputs

## Run locally / on EC2

```bash
cd mf-form-filling-productive
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Add your key:
mkdir -p .streamlit
nano .streamlit/secrets.toml
# GEMINI_API_KEY = "..."

streamlit run app/main.py --server.address 0.0.0.0 --server.port 8080
```

Open:
`http://<PUBLIC-IP>:8080`

## Notes
- Bank templates are included in `assets/bank_forms/` (for reference / future PDF filling).
- This version outputs structured JSON/CSV. PDF auto-fill can be added next.
